contains all images needed for the readme of the repo.
